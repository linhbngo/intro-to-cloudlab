geni.aggregate.protogeni
========================

.. automodule:: geni.aggregate.protogeni
  :undoc-members:
  :inherited-members:
  :members:

