geni.aggregate.transit
======================

.. automodule:: geni.aggregate.transit
  :undoc-members:
  :inherited-members:
  :members:

