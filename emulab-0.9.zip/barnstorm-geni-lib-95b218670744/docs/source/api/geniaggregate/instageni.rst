geni.aggregate.instageni
========================

.. automodule:: geni.aggregate.instageni
  :undoc-members:
  :inherited-members:
  :members:

