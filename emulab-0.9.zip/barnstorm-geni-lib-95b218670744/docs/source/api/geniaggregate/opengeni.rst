geni.aggregate.opengeni
=======================

.. automodule:: geni.aggregate.opengeni
  :undoc-members:
  :inherited-members:
  :members:
